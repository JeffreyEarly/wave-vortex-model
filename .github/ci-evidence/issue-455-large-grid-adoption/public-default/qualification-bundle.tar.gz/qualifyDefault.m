root = "/Users/jearly/Documents/OceanKitRepositories/wvm-v4-cpp-adoption-audit";
here = "/private/tmp/wvm455-default-qualification";
assert(isfile(fullfile(here,"prepared.json")),"Run preparation after promotion first.");
addpath(fullfile(root,"tools"));
configureCIEnvironment(root,"/Users/jearly/Documents/OceanKitRepositories/OceanKit",documentationPackageSpecifier="ClassDocumentation@1.3.2");
checks = jsondecode(fileread(fullfile(here,"focused-tests.json")));
assert(numel(checks)==5 && all([checks.passed]) && ~any([checks.failed]) && ~any([checks.incomplete]));
fprintf("Retaining five passed source-identical focused methods from initial batch.\n");
analyzers = jsondecode(fileread(fullfile(here,"analyzers.json")));
assert(numel(analyzers)==3 && all([analyzers.newFindings]==0));
fprintf("Retaining accepted analyzers: zero new findings; nine baseline warnings.\n");
exportRoot = fullfile(here,"export");
addpath(exportRoot,"-begin");clear WVCompiledBackend
assert(startsWith(string(which("WVCompiledBackend")),exportRoot));
capabilities = WVCompiledBackend.buildForTesting(struct(PackageRoot=exportRoot,CommandFunction=@rejectProviderMutation));
writeJSON(fullfile(here,"capabilities.json"),capabilities);
assert(capabilities.status=="available",capabilities.failure.message);
assert(string(capabilities.module.nonlinearFluxSchedule)=="retained-compact-streamed-target-three-channel-v1");
assert(capabilities.module.requestedPointwiseWorkers==12 && capabilities.module.requestedHorizontalWorkers==12);
assert(capabilities.contract.planCount==17 && capabilities.contract.version==4);
fprintf("PROMOTED_DEFAULT_PUBLIC_BUILD_PASS error=%.17g schedule=%s\n",capabilities.featureValidation.maximumRelativeError,capabilities.module.nonlinearFluxSchedule);
function [status,output] = rejectProviderMutation(command,logPath)
    error("WaveVortexModel:QualificationProviderMutation","Prepared provider unexpectedly requested a command: %s; log %s",command,logPath);
    status = 1; output = ""; %#ok<UNRCH>
end
function writeJSON(path,value)
    f = fopen(path,"w");assert(f>=0);cleanup = onCleanup(@()fclose(f));fwrite(f,jsonencode(value,PrettyPrint=true));
end
