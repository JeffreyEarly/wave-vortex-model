root = "/Users/jearly/Documents/OceanKitRepositories/wvm-v4-cpp-adoption-audit";
here = "/private/tmp/wvm455-default-qualification";
assert(isfile(fullfile(here,"prepared.json")),"Run preparation after promotion first.");
addpath(fullfile(root,"tools"));
configureCIEnvironment(root,"/Users/jearly/Documents/OceanKitRepositories/OceanKit",documentationPackageSpecifier="ClassDocumentation@1.3.2");
import matlab.unittest.TestSuite
suite = TestSuite.fromClass(?TestCompiledKernelIntegration);
results = run(suite);
checks = arrayfun(@(r)struct("name",r.Name,"passed",r.Passed,"failed",r.Failed,"incomplete",r.Incomplete,"duration",r.Duration),results);
writeJSON(fullfile(here,"focused-tests.json"),checks);
assert(numel(results)==5 && all([results.Passed]));
analyzers = struct([]);
for name = ["@WVCompiledBackend/private/wvCompiledBackendConstants.m","UnitTests/TestCompiledKernelIntegration.m","UnitTests/TestWVCompiledBackend.m"]
    findings = checkcode(fullfile(root,name),"-id");
    analyzers(end+1) = struct("path",name,"findings",numel(findings)); %#ok<SAGROW>
    fprintf("%s analyzer findings: %d\n",name,numel(findings));
    assert(isempty(findings));
end
writeJSON(fullfile(here,"analyzers.json"),analyzers);
exportRoot = fullfile(here,"export");
addpath(exportRoot,"-begin");clear WVCompiledBackend
assert(startsWith(string(which("WVCompiledBackend")),exportRoot));
capabilities = WVCompiledBackend.buildForTesting(struct(PackageRoot=exportRoot,CommandFunction=@rejectProviderMutation));
writeJSON(fullfile(here,"capabilities.json"),capabilities);
assert(capabilities.status=="available",capabilities.failure.message);
assert(string(capabilities.module.nonlinearFluxSchedule)=="retained-compact-streamed-target-three-channel-v1");
assert(capabilities.module.requestedPointwiseWorkers==12 && capabilities.module.requestedHorizontalWorkers==12);
assert(capabilities.contract.planCount==17 && capabilities.contract.version==4);
fprintf("PROMOTED_DEFAULT_PUBLIC_BUILD_PASS error=%.17g schedule=%s\n",capabilities.featureValidation.maximumRelativeError,capabilities.module.nonlinearFluxSchedule);
function [status,output] = rejectProviderMutation(command,logPath)
    error("WaveVortexModel:QualificationProviderMutation","Prepared provider unexpectedly requested a command: %s; log %s",command,logPath);
    status = 1; output = ""; %#ok<UNRCH>
end
function writeJSON(path,value)
    f = fopen(path,"w");assert(f>=0);cleanup = onCleanup(@()fclose(f));fwrite(f,jsonencode(value,PrettyPrint=true));
end
