root = "/Users/jearly/Documents/OceanKitRepositories/wvm-v4-cpp-adoption-audit";
here = "/private/tmp/wvm455-default-qualification";
assert(isfile(fullfile(here,"prepared.json")),"Run preparation after promotion first.");
addpath(fullfile(root,"tools"));
configureCIEnvironment(root,"/Users/jearly/Documents/OceanKitRepositories/OceanKit",documentationPackageSpecifier="ClassDocumentation@1.3.2");
checks = jsondecode(fileread(fullfile(here,"focused-tests.json")));
assert(numel(checks)==5 && all([checks.passed]) && ~any([checks.failed]) && ~any([checks.incomplete]));
fprintf("Retaining five passed source-identical focused methods from initial batch.\n");
analyzers = {};
for name = ["@WVCompiledBackend/private/wvCompiledBackendConstants.m","UnitTests/TestCompiledKernelIntegration.m","UnitTests/TestWVCompiledBackend.m"]
    findings = checkcode(fullfile(root,name),"-id");
    baselineFindings = [];
    if name=="UnitTests/TestCompiledKernelIntegration.m"
        baselineFindings = checkcode(fullfile(here,"baseline","TestCompiledKernelIntegration.m"),"-id");
        assert(numel(findings)==numel(baselineFindings) && isequal(sort(string({findings.message})),sort(string({baselineFindings.message}))));
    else
        assert(isempty(findings));
    end
    analyzers{end+1} = struct("path",name,"findings",numel(findings),"baselineFindings",numel(baselineFindings),"newFindings",numel(findings)-numel(baselineFindings),"details",findings); %#ok<SAGROW>
    fprintf("%s analyzer findings: %d; unchanged baseline: %d\n",name,numel(findings),numel(baselineFindings));
end
writeJSON(fullfile(here,"analyzers.json"),analyzers);
exportRoot = fullfile(here,"export");
addpath(exportRoot,"-begin");clear WVCompiledBackend
assert(startsWith(string(which("WVCompiledBackend")),exportRoot));
capabilities = WVCompiledBackend.buildForTesting(struct(PackageRoot=exportRoot,CommandFunction=@rejectProviderMutation));
writeJSON(fullfile(here,"capabilities.json"),capabilities);
assert(capabilities.status=="available",capabilities.failure.message);
assert(string(capabilities.module.nonlinearFluxSchedule)=="retained-compact-streamed-target-three-channel-v1");
assert(capabilities.module.requestedPointwiseWorkers==12 && capabilities.module.requestedHorizontalWorkers==12);
assert(capabilities.contract.planCount==17 && capabilities.contract.version==4);
fprintf("PROMOTED_DEFAULT_PUBLIC_BUILD_PASS error=%.17g schedule=%s\n",capabilities.featureValidation.maximumRelativeError,capabilities.module.nonlinearFluxSchedule);
function [status,output] = rejectProviderMutation(command,logPath)
    error("WaveVortexModel:QualificationProviderMutation","Prepared provider unexpectedly requested a command: %s; log %s",command,logPath);
    status = 1; output = ""; %#ok<UNRCH>
end
function writeJSON(path,value)
    f = fopen(path,"w");assert(f>=0);cleanup = onCleanup(@()fclose(f));fwrite(f,jsonencode(value,PrettyPrint=true));
end
