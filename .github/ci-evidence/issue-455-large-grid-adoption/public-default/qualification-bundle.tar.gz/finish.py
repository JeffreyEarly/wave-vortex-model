"""Validate the completed local campaign and write a separate source-bound receipt."""
from pathlib import Path
import hashlib,json,datetime
HERE=Path(__file__).resolve().parent
prepared=json.loads((HERE/'prepared.json').read_text())
ROOT=Path(prepared['sourceRoot']);EXPORT=Path(prepared['exportRoot'])
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for row in prepared['sourceSHA256']:
 assert sha(ROOT/row['path'])==row['sha256'],'Source changed during qualification: '+row['path']
 if (EXPORT/row['path']).is_file():assert sha(EXPORT/row['path'])==row['sha256']
for row in prepared['originalProviderSHA256']:assert sha(row['path'])==row['sha256'],'Original provider changed.'
cap=json.loads((HERE/'capabilities.json').read_text())
assert cap['status']=='available'
assert cap['module']['nonlinearFluxSchedule']=='retained-compact-streamed-target-three-channel-v1'
checks=json.loads((HERE/'focused-tests.json').read_text());assert len(checks)==5 and all(v['passed'] and not v['failed'] and not v['incomplete'] for v in checks)
analyzers=json.loads((HERE/'analyzers.json').read_text());assert all(v['newFindings']==0 for v in analyzers)
baseline_path=ROOT/'.github/ci-evidence/issue-358-compact-correctness/qualification.json'
baseline=json.loads(baseline_path.read_text());changed=[];unchanged=[]
for row in baseline['sourceSHA256']:
 (unchanged if sha(ROOT/row['path'])==row['sha256'] else changed).append(row['path'])
allowed={'CompiledKernel/CMakeLists.txt','CompiledKernel/include/WaveVortexKernel/WVTransformConstantStratificationKernel.hpp','@WVCompiledBackend/private/wvCompiledBackendConstants.m','UnitTests/TestWVCompiledBackend.m','tools/compiled-kernel/CMakeLists.txt','tools/compiled-kernel/tests/TestWVCompactConstantSchedule.cpp'}
assert set(changed)<=allowed,'Unexpected baseline numerical-source change: '+str(set(changed)-allowed)
artifacts=[]
requiredArtifacts=['prepared.json','focused-tests.json','analyzers.json','capabilities.json','qualification.log','prepare.py','qualifyFresh.m','finish.py','baseline/TestCompiledKernelIntegration.m']
optionalArtifacts=['qualifyDefault.m','initial-driver-failure.log','initial-qualifyDefault.m','analyzer-baseline-discovery.log','analyzer-discovery-driver.m','export-manifest-omission.log','initial-prepared.json','analyzer-accepted-driver.m']
for name in requiredArtifacts+optionalArtifacts:
 p=HERE/name
 if not p.is_file():
  assert name in optionalArtifacts,name
  continue
 artifacts.append(dict(path=str(p),sha256=sha(p)))
module=EXPORT/'wv_compiled_backend_mex.mexmaca64'
report=dict(scope='issue-455-promoted-public-default-qualification',createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=prepared['sourceCommit'],workingTreeChanges=prepared['workingTreeChanges'],sourceRoot=str(ROOT),exportRoot=str(EXPORT),sourceOverrides=[],compactConstantDefault=True,sourceSHA256=prepared['sourceSHA256'],module=dict(path=str(module),sha256=sha(module)),originalProviderUnchanged=True,originalProviderSHA256=prepared['originalProviderSHA256'],gates=dict(focusedTests=checks,analyzers=analyzers,freshPublicBuild=True,numerical=cap['featureValidation'],defaultSchedule=cap['module']['nonlinearFluxSchedule'],contractVersion=4,logicalPlanCount=17,estimateAndMetadataAndLifecycle=True),baselineEquivalence=dict(receiptPath=str(baseline_path),receiptSHA256=sha(baseline_path),unchangedSourcePaths=unchanged,changedPolicyOrTestPaths=changed,interpretation='Old explicitly-ON candidate binaries retain original provenance. Numerical implementation bytes are unchanged; constructor/source defaults and tests are separately qualified by this fresh public build.'),artifacts=artifacts,historicalIterations=['Five contract methods passed in initial batch; temporary empty-struct analyzer receipt collector failed before public build. Retry used cell receipt collection and retained the five passing source-identical test results.','Analyzer required zero total findings initially, discovering9 pre-existing warnings in TestCompiledKernelIntegration; compared exact107894a1 baseline and required identical warning messages/count plus zero new findings.','Minimal export initially omitted the unchanged production native-fftw-provider.env; copied it before public build and added its digest. Public build rerun alone; prior tests/analyzers retained.'],limitations=['This is build/default/source-equivalence qualification, not a performance result.','Large-grid decision and accepted small-grid cost are recorded by the coordinator.','Historical receipts and original binaries were not rewritten.'])
(HERE/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(HERE/'qualification.json');print('module SHA256',sha(module))
