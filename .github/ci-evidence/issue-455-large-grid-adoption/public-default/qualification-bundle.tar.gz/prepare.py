"""Run only AFTER promotion and coordinator workload release; never edits source."""
from pathlib import Path
import hashlib,json,shutil,subprocess,datetime
ROOT=Path('/Users/jearly/Documents/OceanKitRepositories/wvm-v4-cpp-adoption-audit')
HERE=Path(__file__).resolve().parent
EXPORT=HERE/'export'
CACHE=Path('/private/tmp/wvm358-public-default-export/.compiled-backend-cache')
PROVIDER=Path('/Users/jearly/Documents/OceanKitRepositories/wave-vortex-model/.compiled-backend-cache/provider/native-neon-pthreads/lib')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
constants=(ROOT/'@WVCompiledBackend/private/wvCompiledBackendConstants.m').read_text()
assert '"compactConstantDefault",true' in constants,'Promotion not applied; do not override constants.'
selection=json.loads((ROOT/'CompiledKernel/source-selection.json').read_text())
assert selection['constantSpectralSchedule']['productionDefault'] is True
assert selection['contract']['knownScratch']=='4C+6R'
assert not EXPORT.exists(),'Use a new campaign directory; never overwrite qualification export.'
EXPORT.mkdir()
(HERE/'baseline').mkdir(exist_ok=True)
(HERE/'baseline/TestCompiledKernelIntegration.m').write_bytes(subprocess.check_output(['git','show','107894a1:UnitTests/TestCompiledKernelIntegration.m'],cwd=ROOT))
shutil.copytree(ROOT/'@WVCompiledBackend',EXPORT/'@WVCompiledBackend',symlinks=True)
for package,subdirs in [('CompiledKernel',['include','src','adapters']),('PortableRuntime',['include','src'])]:
 for name in subdirs:shutil.copytree(ROOT/package/name,EXPORT/package/name,symlinks=True)
 for name in ['CMakeLists.txt','source-selection.json','README.md']:shutil.copy2(ROOT/package/name,EXPORT/package/name)
shutil.copy2(ROOT/'CompiledKernel/native-fftw-provider.env',EXPORT/'CompiledKernel/native-fftw-provider.env')
# Only build prerequisites: no old stage/module, validated-build record or logs.
for name in ['downloads','source','build','provider']:
 shutil.copytree(CACHE/name,EXPORT/'.compiled-backend-cache'/name,symlinks=True)
oldlib=CACHE/'provider/native-neon-pthreads/lib'
lib=EXPORT/'.compiled-backend-cache/provider/native-neon-pthreads/lib'
for name in ['libfftw3.3.dylib','libfftw3_threads.3.dylib']:
 p=lib/name
 subprocess.run(['install_name_tool','-id',str(p),str(p)],check=True)
 if 'threads' in name:subprocess.run(['install_name_tool','-change',str(oldlib/'libfftw3.3.dylib'),str(lib/'libfftw3.3.dylib'),str(p)],check=True)
 subprocess.run(['codesign','--force','--sign','-',str(p)],check=True)
sources=[]
for p in sorted(EXPORT.rglob('*')):
 if p.is_file() and '.compiled-backend-cache' not in p.parts:
  rel=p.relative_to(EXPORT);assert sha(p)==sha(ROOT/rel),str(rel)
  sources.append(dict(path=str(rel),sha256=sha(p)))
for rel in ['UnitTests/TestCompiledKernelIntegration.m','UnitTests/TestWVCompiledBackend.m']:
 sources.append(dict(path=rel,sha256=sha(ROOT/rel)))
report=dict(scope='issue-455-public-default-preparation',createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceRoot=str(ROOT),sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),workingTreeChanges=bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)),exportRoot=str(EXPORT),sourceOverrides=[],sourceSHA256=sources,originalProviderSHA256=[dict(path=str(p),sha256=sha(p)) for p in sorted(PROVIDER.glob('*.dylib'))])
(HERE/'prepared.json').write_text(json.dumps(report,indent=2)+'\n')
print('Exact-source export prepared; public default remains unmodified.')
